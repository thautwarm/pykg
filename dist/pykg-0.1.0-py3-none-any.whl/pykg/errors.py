Fatal = (SystemExit, KeyboardInterrupt)

class InvalidComfigVersion(Exception):
    pass
