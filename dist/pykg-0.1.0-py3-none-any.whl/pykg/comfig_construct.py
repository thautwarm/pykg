from __future__ import annotations as __01asda1ha
from lark import Token as token
import dataclasses as dataclasses
import typing as typing
from .comfig_require import (one_or_list,sink_comments,mk_specifier_set,mk_specifier,parse_version,CCommented,CList,CCons,CSpec,CVer,CBool,CStr,CNum,CNull,Component,COMPACT,PATCH,LE,GE,LT,GT,NE,EQ,operator,toArray,add,toNum,lexeme,unesc,SpecifierSet,specifier,version,array,num)

